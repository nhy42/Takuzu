//
// Created by Paul on 15/04/2022.
//

#ifndef TAKUZU_EXAMPLE_H
#define TAKUZU_EXAMPLE_H


int** convertToTakuzu4(int tab4[4][4]);
int** convertToTakuzu8(int tab8[8][8]);

#endif //TAKUZU_EXAMPLE_H
